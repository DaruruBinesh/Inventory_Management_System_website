
<!DOCTYPE html>
<html lang="en">
<head>
<title>Inventory Management System By Daruru Binesh (18BCE0872)</title>


<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/fasthover.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />

<link href="css/font-awesome.css" rel="stylesheet"> 

<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="css/jquery.countdown.css" /> 

<link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>

</head> 
<body>
	
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
	
	
	<div class="header" id="home1">
		<div class="container">
		
			<div class="w3l_logo">
				<h1><a href="index.php">Inventory Management System</a></h1>
			</div>
		
		</div>
	</div>
	
	<div class="navigation">
		<div class="container">
			<nav class="navbar navbar-default">
				
				<div class="navbar-header nav_2">
					<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div> 
				<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
					<ul class="nav navbar-nav">
						<li ><a href="index.php" class="act">Home</a></li>	
						
						<li><a href="admin/login.php">Admin</a></li> 
					  
						
					</ul>
				</div>
			</nav>
		</div>
	</div>
	
	<div class="banner">
		<div class="container">
			<h3>Inventory Management, <span>System</span></h3>
		</div>
	</div>
	
	<div class="footer">
		
		<div class="footer-copy">
			<div class="footer-copy1">
				<div class="footer-copy-pos">
					<a href="#home1" class="scroll"><img src="images/arrow.png" alt=" " class="img-responsive" /></a>
				</div>
			</div>
			<div class="container">
				<p>Inventory Management System By Daruru Binesh (18BCE0872)</p>
			</div>
		</div>
	</div>
	
	<script src="js/minicart.js"></script>
	<script>
        w3ls.render();

        w3ls.cart.on('w3sb_checkout', function (evt) {
        	var items, len, i;

        	if (this.subtotal() > 0) {
        		items = this.items();

        		for (i = 0, len = items.length; i < len; i++) { 
        		}
        	}
        });
    </script>  
	
</body>
</html>